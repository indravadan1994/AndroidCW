package com.example.macstudent.helloworld;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class FirstActivity extends AppCompatActivity implements View.OnClickListener{
    TextView txtTitle;
    EditText txtName, txtPassword;
    Button btnSubmit,btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtName = (EditText)findViewById(R.id.txtUsername);
        txtPassword = (EditText)findViewById(R.id.txtPassword);

        btnSubmit = (Button)findViewById(R.id.button2);
        btnCancel = (Button)findViewById(R.id.button3);

        btnSubmit.setOnClickListener(this);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int a,b,c;
                a = Integer.parseInt(txtName.getText().toString());
                b = Integer.parseInt(txtPassword.getText().toString());

                c = a - b;

                String Result = String.format(Locale.ENGLISH,"Substraction : %d", c);
                Toast.makeText(getApplicationContext(),Result, Toast.LENGTH_SHORT).show();
            }
        });


        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a,b,c;
                a = Integer.parseInt(txtName.getText().toString());
                b = Integer.parseInt(txtPassword.getText().toString());

                c = a + b;
                String Result = String.format(Locale.ENGLISH,"Addition : %d", c);
                Toast.makeText(getApplicationContext(),Result, Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(getApplicationContext(),"Helloworld", Toast.LENGTH_SHORT).show();

    }
}
